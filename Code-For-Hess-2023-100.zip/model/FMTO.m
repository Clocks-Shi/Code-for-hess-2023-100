function EL=FMTO(N,X)
        EL=N.*X;
end