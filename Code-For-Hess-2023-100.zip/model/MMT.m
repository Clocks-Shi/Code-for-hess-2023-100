function EL=MMT(N,X,Y)
        EL=N.*X+Y;
end