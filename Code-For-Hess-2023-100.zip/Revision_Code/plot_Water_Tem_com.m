clear,clc
close all
%%
in_path='E:\Paper\Lake_ET\ET_ICE_Cover\indata\QHH_FB_Tem_2hours_data\Daily\';
data=xlsread([in_path,'Tem_dailyZ.xlsx']);
dataO=data(2:end,2:10);
dataS1=data(2:end,13:21);
dataS2=data(2:end,24:32);
[m,n]=size(dataO);
x=1:1:m;
%%
name={'0.5 m','1.0 m','3.0 m','5.0 m','7.0 m','9.0 m','11.0 m','13.0 m','15.0 m'};
H1=figure(1);
set(H1,'pos',[ 0.0082    0.0386    1.5184    0.7400]*10^3);
ha = tight_subplot(3,3,[.12 .045],[.12 .05],[.06 .06]); % �м�����м�������±߽磬�ϱ߽磬��߽磬�ұ߽�
for i = 1:n
    axes(ha(i));
    dataOi=dataO(:,i);
    dataSi=dataS1(:,i);
    h1 = plot(x,dataOi,'ro','Linewidth',1.5);
    hold on
    h2 = plot(x,dataSi,'b*','Linewidth',1.5);
    box on
    xlim([0 m])
    ylim([5 20]);
%     set(gca ,'XTick',1:30:365);
%     set(gca ,'XTickLabel',num2cell(ax));
    set(gca ,'fontsize',14,'FontWeigh','bold');
    set(gca ,'fontsize',14,'FontWeigh','bold');
     xlabel('\fontname{Arial}Days', 'fontsize',16,'FontWeigh','bold');
     ylabel('Tw (��C)', 'fontname', 'arial', 'fontsize',16,'FontWeigh','bold'); 
     title(name{i}, 'FontName','Arail','fontsize',18,'FontWeigh','bold');
end
%%
axes(ha(6))
legend1 = legend([h1,h2],{'Observation','Simulation'});
set(legend1,...
    'Position',[0.0593320129766255 0.757708392202034 0.112499997913837 0.0709459474924449],...
    'Interpreter','none',...
    'FontName','Arail',...
    'FontSize',14,...
    'EdgeColor','none');
%%
print('-dpng','-r300', [in_path,'FS_O_S_Tw02']);