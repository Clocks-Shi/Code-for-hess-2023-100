clear,clc
close all
%%
in_path1='D:\QTP_RS_Data\��ظ�ԭ0.05�����ջ�ѩ������ݼ���2000-2018��\';
in_path2='E:\Paper\Lake_ET\ET_ICE_Cover\indata\inmap\QHH_Raster\';
o_paht='E:\Paper\Lake_ET\ET_ICE_Cover\indata\Snow\';
year=2001:2018;
L=length(year);
%% limits of our region
% load the study_region map
[SR,R1]=geotiffread([in_path2,'QHH2018_005.tif']);
lat=37.24:-0.05:36.55;
lon=99.6164:0.05:100.766;
SP=double(SR);
[m,n]=size(SP);
SPL=SP;
SPL(SPL==255)=[];
LL=length(SPL);
Snow_QHH=nan(size(SP,1),size(SP,2));
Toplimit = lat(1);
Leftlimit =lon(1);
GToplimit = 39.85;
GLeftlimit = 68;
%%
Snow_QHHday=cell(365,L);
SCR=nan(365,L);
MSD=nan(365,L);
for i=1:L
    in_pathy=[in_path1,num2str(year(i)),in_path1(end)];
    fy=dir([in_pathy,'*.tif']);
    Lf=length(fy);
    for j=1:Lf
        fn=fy(j).name;
        [Sw,R2]=geotiffread([in_pathy,fn]);
        Sw=double(Sw);
        for ii1 = 1:m
            for jj1 = 1:n
                if SP(ii1,jj1) ==255
                    Snow_QHH(ii1,jj1) = nan;
                else
                    X = Toplimit-((ii1-1)*(1/20)+(1/20)/2); %(the latitude of study region)
                    a = floor((GToplimit-X)/(1/20))+1;
                    Y = (jj1-1)*(1/20)+(1/20)/2+Leftlimit;
                    b = floor((Y-GLeftlimit)/(1/20))+1;
                    Snow_QHH(ii1,jj1) = Sw(a,b)*10;   %% Unite mm
                end
            end
        end
        Snow_QHHday{j,i}=Snow_QHH;
        Snow_QHH(Snow_QHH<0.1)=nan;
        Snow_QHHL=Snow_QHH;
        Snow_QHHL(isnan(Snow_QHHL))=[];
        sl=length(Snow_QHHL);
        if sl==0
            SCR(j,i)=nan;
            MSD(j,i)=nan;
        else
            SCR(j,i)=100*sl/LL;
            MSD(j,i)=nanmean(Snow_QHHL);
            
        end
        clear Snow_QHH Snow_QHHL sl
    end
end
%%
save([o_path,'Snow_Depth_QHL.mat'],'Snow_QHHday','SCR','MSD');
